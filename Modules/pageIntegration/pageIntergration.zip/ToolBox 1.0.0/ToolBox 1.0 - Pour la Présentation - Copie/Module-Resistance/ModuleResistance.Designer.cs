﻿namespace Module_Resistance
{
    partial class FormResistance 
    {
        /// <summary>
        /// Variable nécessaire au concepteur.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Nettoyage des ressources utilisées.
        /// </summary>
        /// <param name="disposing">true si les ressources managées doivent être supprimées ; sinon, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Code généré par le Concepteur Windows Form

        /// <summary>
        /// Méthode requise pour la prise en charge du concepteur - ne modifiez pas
        /// le contenu de cette méthode avec l'éditeur de code.
        /// </summary>
        private void InitializeComponent()
        {
            this.panelSearch = new System.Windows.Forms.Panel();
            this.labelValue = new System.Windows.Forms.Label();
            this.buttonValidate = new System.Windows.Forms.Button();
            this.textBoxValueToCheck = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.panelTolerance = new System.Windows.Forms.Panel();
            this.panelNumberTwo = new System.Windows.Forms.Panel();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panelMultiplicator = new System.Windows.Forms.Panel();
            this.panelNumberOne = new System.Windows.Forms.Panel();
            this.panelSearch.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // panelSearch
            // 
            this.panelSearch.Controls.Add(this.labelValue);
            this.panelSearch.Controls.Add(this.buttonValidate);
            this.panelSearch.Controls.Add(this.textBoxValueToCheck);
            this.panelSearch.Controls.Add(this.label1);
            this.panelSearch.Location = new System.Drawing.Point(19, 17);
            this.panelSearch.Name = "panelSearch";
            this.panelSearch.Size = new System.Drawing.Size(585, 176);
            this.panelSearch.TabIndex = 0;
            this.panelSearch.Tag = "";
            // 
            // labelValue
            // 
            this.labelValue.AutoSize = true;
            this.labelValue.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelValue.Location = new System.Drawing.Point(241, 104);
            this.labelValue.Name = "labelValue";
            this.labelValue.Size = new System.Drawing.Size(71, 24);
            this.labelValue.TabIndex = 3;
            this.labelValue.Text = "Valeur";
            // 
            // buttonValidate
            // 
            this.buttonValidate.Location = new System.Drawing.Point(352, 33);
            this.buttonValidate.Name = "buttonValidate";
            this.buttonValidate.Size = new System.Drawing.Size(101, 23);
            this.buttonValidate.TabIndex = 2;
            this.buttonValidate.Text = "tester";
            this.buttonValidate.UseVisualStyleBackColor = true;
            this.buttonValidate.Click += new System.EventHandler(this.buttonValidate_Click);
            // 
            // textBoxValueToCheck
            // 
            this.textBoxValueToCheck.Location = new System.Drawing.Point(211, 33);
            this.textBoxValueToCheck.Name = "textBoxValueToCheck";
            this.textBoxValueToCheck.Size = new System.Drawing.Size(100, 20);
            this.textBoxValueToCheck.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(85, 36);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(109, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Saisissez une valeur :";
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.panel2.Controls.Add(this.panelTolerance);
            this.panel2.Controls.Add(this.panelNumberTwo);
            this.panel2.Location = new System.Drawing.Point(185, 60);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(196, 64);
            this.panel2.TabIndex = 0;
            // 
            // panelTolerance
            // 
            this.panelTolerance.BackColor = System.Drawing.SystemColors.Control;
            this.panelTolerance.Location = new System.Drawing.Point(159, 0);
            this.panelTolerance.Name = "panelTolerance";
            this.panelTolerance.Size = new System.Drawing.Size(25, 64);
            this.panelTolerance.TabIndex = 4;
            // 
            // panelNumberTwo
            // 
            this.panelNumberTwo.BackColor = System.Drawing.SystemColors.Control;
            this.panelNumberTwo.Location = new System.Drawing.Point(54, 0);
            this.panelNumberTwo.Name = "panelNumberTwo";
            this.panelNumberTwo.Size = new System.Drawing.Size(25, 64);
            this.panelNumberTwo.TabIndex = 2;
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.panelMultiplicator);
            this.panel1.Controls.Add(this.panelNumberOne);
            this.panel1.Controls.Add(this.panel2);
            this.panel1.Location = new System.Drawing.Point(19, 210);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(585, 200);
            this.panel1.TabIndex = 1;
            this.panel1.Tag = "";
            // 
            // panelMultiplicator
            // 
            this.panelMultiplicator.BackColor = System.Drawing.SystemColors.Control;
            this.panelMultiplicator.Location = new System.Drawing.Point(284, 60);
            this.panelMultiplicator.Name = "panelMultiplicator";
            this.panelMultiplicator.Size = new System.Drawing.Size(25, 64);
            this.panelMultiplicator.TabIndex = 3;
            // 
            // panelNumberOne
            // 
            this.panelNumberOne.Location = new System.Drawing.Point(198, 60);
            this.panelNumberOne.Name = "panelNumberOne";
            this.panelNumberOne.Size = new System.Drawing.Size(25, 64);
            this.panelNumberOne.TabIndex = 1;
            // 
            // FormResistance
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(626, 431);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.panelSearch);
            this.Name = "FormResistance";
            this.Text = "Module de resistance";
            this.panelSearch.ResumeLayout(false);
            this.panelSearch.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panelSearch;
        private System.Windows.Forms.Label labelValue;
        private System.Windows.Forms.Button buttonValidate;
        private System.Windows.Forms.TextBox textBoxValueToCheck;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panelTolerance;
        private System.Windows.Forms.Panel panelNumberTwo;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panelMultiplicator;
        private System.Windows.Forms.Panel panelNumberOne;
    }
}

